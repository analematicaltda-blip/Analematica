"""Reviewed sold room-nights, never inferred from bookings or product prices.
Observations are append-only, tied to a capacity version and knowledge timestamp.
They neither book revenue nor certify payment, physical stays or source authenticity.
"""
from datetime import datetime,timedelta
from uuid import UUID,uuid5
import re
from django.db import transaction
from django.utils import timezone
from apps.core_erp.outbox_models import OutboxEvent
from apps.core_erp.accounting.integrity import fingerprint
from apps.core_erp.accounting.exceptions import AccountingError
from . import tourism_metrics as capacity

NS=UUID('f7fdbfd9-7dd5-4e2d-b1af-59dc2ac3ac42')
REVIEW='accounting.hotel-sales.reviewed.v1'
RECORDED='accounting.hotel-sales.recorded.v1'

def rows(company,provider,day=None):
    q=OutboxEvent.objects.filter(event_type=RECORDED,payload__company_id=str(company.pk),payload__provider_id=str(provider.pk))
    return q.filter(payload__day=day) if day else q

def verified(row,company,provider):
    if row is None:raise AccountingError('Sold room-night observation missing.')
    p=row.payload;b=p.get('observation');s=b.get('snapshot') if isinstance(b,dict) else None
    if not isinstance(s,dict) or row.domain!='accounting' or row.aggregate_root!=str(provider.pk) or row.version!=1 or p.get('company_id')!=str(company.pk) or p.get('provider_id')!=str(provider.pk) or s.get('company_id')!=str(company.pk) or s.get('provider_id')!=str(provider.pk) or p.get('observation_digest')!=fingerprint(b) or p.get('day')!=s.get('day') or type(b.get('revision')) is not int or not 1<=b['revision']<=100 or p.get('revision')!=b['revision'] or row.pk!=uuid5(NS,'recorded:'+str(company.pk)+':'+s['day']+':'+str(b['revision'])):raise AccountingError('Sold room-night evidence changed.')
    review=OutboxEvent.objects.filter(pk=p.get('review_id'),event_type=REVIEW).first()
    if review is None or review.pk!=uuid5(NS,'review:'+fingerprint(b)) or review.payload!={'company_id':str(company.pk),'provider_id':str(provider.pk),'review':b,'review_digest':fingerprint(b)}:raise AccountingError('Sold room-night review changed.')
    known=row.created_at.isoformat()
    if p.get('known_at')!=known or p.get('record_digest')!=fingerprint({'observation':b,'known_at':known}):raise AccountingError('Sold room-night knowledge timestamp changed.')
    ids=s.get('sold_room_ids')
    if not isinstance(ids,list) or len(ids)>50 or ids!=sorted(set(ids)) or any(str(UUID(i))!=i for i in ids):raise AccountingError('Sold room-night identities changed.')
    origin=OutboxEvent.objects.filter(pk=s.get('capacity_id'),event_type=capacity.RECORDED).first()
    if origin is None:raise AccountingError('Capacity origin missing.')
    original=capacity._verified(origin,company,provider)
    if fingerprint(original)!=s.get('capacity_digest') or original['snapshot']['day']!=s['day'] or set(ids)-set(original['snapshot']['room_ids']):raise AccountingError('Sold room-nights exceed accepted capacity or origin changed.')
    return b

def head(company,provider,day):
    row=rows(company,provider,day).order_by('-payload__revision').first()
    return row,verified(row,company,provider) if row else None

def snapshot(company,provider,day,sold_room_ids):
    if capacity._day(day)!=timezone.localdate():raise AccountingError('Only current daily sales may be observed; no invented historical nights.')
    if not isinstance(sold_room_ids,list) or len(sold_room_ids)>50:raise AccountingError('Explicit sold room identities required, including zero.')
    ids=sorted(str(UUID(str(i))) for i in sold_room_ids)
    if len(set(ids))!=len(ids):raise AccountingError('Duplicate sold room-night.')
    row=capacity._records(company,provider,day).order_by('-payload__revision').first()
    if row is None:raise AccountingError('Record reviewed capacity before sold room-nights.')
    b=capacity._verified(row,company,provider)
    if set(ids)-set(b['snapshot']['room_ids']):raise AccountingError('Sold room-night outside recorded capacity.')
    return {'company_id':str(company.pk),'provider_id':str(provider.pk),'day':day,'sold_room_ids':ids,'capacity_id':str(row.pk),'capacity_digest':fingerprint(b),'unit':'sold_room_night','source':'owner_reviewed_sales_evidence','independently_verified':False}

def flags(company):return {'company_id':str(company.pk),'ledger_written':False,'independently_verified':False,'confirmations_restored':False}

@transaction.atomic
def sources(*,actor,provider_id):
    _,provider,company=capacity._context(actor,provider_id);day=timezone.localdate().isoformat();row=capacity._records(company,provider,day).order_by('-payload__revision').first();b=capacity._verified(row,company,provider) if row else None;old,sale=head(company,provider,day)
    return {**flags(company),'read_only':True,'day':day,'capacity_id':str(row.pk) if row else None,'available_room_ids':b['snapshot']['room_ids'] if b else [],'revision':sale['revision'] if sale else 0,'recorded':sale,'matches_current_capacity':bool(sale and row and sale['snapshot']['capacity_id']==str(row.pk))}

@transaction.atomic
def review_sales(*,actor,provider_id,day,sold_room_ids,evidence_digest,expected_revision,confirmed):
    user,provider,company=capacity._context(actor,provider_id)
    if confirmed is not True or type(expected_revision) is not int or expected_revision<0 or not isinstance(evidence_digest,str) or not re.fullmatch('[0-9a-f]{64}',evidence_digest):raise AccountingError('First sales review, revision and evidence required.')
    s=snapshot(company,provider,day,sold_room_ids);_,previous=head(company,provider,day)
    if expected_revision!=(previous['revision'] if previous else 0) or expected_revision>=100:raise AccountingError('Sales revision changed or bounded history full.')
    b={'snapshot':s,'evidence_digest':evidence_digest,'reviewed_by':str(user.pk),'expected_revision':expected_revision,'revision':expected_revision+1,'expires_at':(timezone.now()+timedelta(minutes=15)).isoformat()};identifier=uuid5(NS,'review:'+fingerprint(b))
    OutboxEvent.objects.create(id=identifier,event_type=REVIEW,domain='accounting',aggregate_root=str(provider.pk),version=1,payload={'company_id':str(company.pk),'provider_id':str(provider.pk),'review':b,'review_digest':fingerprint(b)})
    return {**flags(company),'review_id':str(identifier),'preview':b}

@transaction.atomic
def record_sales(*,actor,provider_id,review_id,confirmed):
    user,provider,company=capacity._context(actor,provider_id);row=OutboxEvent.objects.filter(pk=UUID(str(review_id)),event_type=REVIEW,payload__company_id=str(company.pk),payload__provider_id=str(provider.pk)).first();b=row.payload.get('review') if row else None
    if confirmed is not True or not isinstance(b,dict) or row.pk!=uuid5(NS,'review:'+fingerprint(b)) or row.payload.get('review_digest')!=fingerprint(b) or b.get('reviewed_by')!=str(user.pk):raise AccountingError('Second sales confirmation by same owner required.')
    s=b['snapshot'];identifier=uuid5(NS,'recorded:'+str(company.pk)+':'+s['day']+':'+str(b['revision']));old=OutboxEvent.objects.filter(pk=identifier).first()
    if old:
        saved=verified(old,company,provider)
        if saved!=b or old.payload['review_id']!=str(row.pk):raise AccountingError('Sales version already recorded by another review.')
        return {**flags(company),'observation_id':str(identifier),'revision':b['revision'],'replayed':True}
    if timezone.now()>=datetime.fromisoformat(b['expires_at']) or snapshot(company,provider,s['day'],s['sold_room_ids'])!=s:raise AccountingError('Capacity changed or sales review expired.')
    old,previous=head(company,provider,s['day'])
    if b['expected_revision']!=(previous['revision'] if previous else 0):raise AccountingError('Sales revision changed before confirmation.')
    p={'company_id':str(company.pk),'provider_id':str(provider.pk),'day':s['day'],'revision':b['revision'],'observation':b,'observation_digest':fingerprint(b),'review_id':str(row.pk)}
    recorded=OutboxEvent.objects.create(id=identifier,event_type=RECORDED,domain='accounting',aggregate_root=str(provider.pk),version=1,payload=p)
    if recorded.created_at<row.created_at or (old is not None and recorded.created_at<old.created_at):raise AccountingError('Knowledge clock moved backward.')
    known=recorded.created_at.isoformat();p.update(known_at=known,record_digest=fingerprint({'observation':b,'known_at':known}));OutboxEvent.objects.filter(pk=recorded.pk).update(payload=p);recorded.payload=p;verified(recorded,company,provider)
    return {**flags(company),'observation_id':str(identifier),'revision':b['revision'],'replayed':False}

def ratios(company,provider,selected,cutoff,revenue):
    """Use latest known sales per day, and exactly the selected capacity versions."""
    found=list(rows(company,provider).filter(payload__day__gte=selected[0][1]['snapshot']['day'],payload__day__lte=selected[-1][1]['snapshot']['day'],created_at__lte=cutoff).order_by('-payload__revision')[:501])
    if len(found)>500:raise AccountingError('Sales history exceeds bounded reporting window.')
    by_day={}
    for row in found:
        if row.payload.get('day') not in by_day:by_day[row.payload['day']]=(row,verified(row,company,provider))
    missing=[];changed=[];count=0;sources=[]
    for cap,body in selected:
        day=body['snapshot']['day'];pair=by_day.get(day)
        if pair is None:missing.append(day);continue
        row,sale=pair
        if sale['snapshot']['capacity_id']!=str(cap.pk):changed.append(day);continue
        count+=len(sale['snapshot']['sold_room_ids']);sources.append({'observation_id':str(row.pk),'day':day,'revision':sale['revision'],'sold_rooms':len(sale['snapshot']['sold_room_ids']),'known_at':row.created_at.isoformat(),'capacity_id':str(cap.pk)})
    reason='MISSING_SOLD_ROOM_NIGHTS' if missing else 'SALES_CAPACITY_VERSION_CHANGED' if changed else None
    result={'sold_room_days':None,'occupancy_percent':None,'adr':None,'sold_sources':sources,'missing_sales_days':missing,'sales_capacity_changed_days':changed,'sales_unavailable_reason':reason}
    if reason:return result
    from decimal import Decimal,localcontext,ROUND_HALF_UP
    available=sum(len(b['snapshot']['room_ids']) for _,b in selected);result['sold_room_days']=count
    with localcontext() as ctx:
        ctx.prec=50
        if available:result['occupancy_percent']=format((Decimal(count)*100/available).quantize(Decimal('.0001'),rounding=ROUND_HALF_UP),'.4f')
        if count:result['adr']=format((Decimal(revenue)/100/count).quantize(Decimal('.0001'),rounding=ROUND_HALF_UP),'.4f')
    result['sales_unavailable_reason']='ZERO_AVAILABLE_ROOM_DAYS' if not available else 'ZERO_SOLD_ROOM_NIGHTS' if not count else None
    return result
