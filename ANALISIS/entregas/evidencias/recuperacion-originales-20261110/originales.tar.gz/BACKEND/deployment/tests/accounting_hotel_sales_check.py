"""Sold room-night evidence and occupancy/ADR; disposable synthetic hotel schema."""
import runpy,unittest,uuid
from pathlib import Path
from datetime import timedelta
from unittest.mock import patch
fixture=runpy.run_path(str(Path(__file__).with_name('accounting_tourism_metrics_check.py')),run_name='hotel_sales_fixture')
from apps.prestadores.mi_negocio.gestion_contable.contabilidad import hotel_sales as sales
from apps.prestadores.mi_negocio.gestion_contable.contabilidad import tourism_metrics as capacity
from apps.core_erp.accounting.exceptions import AccountingError
from apps.core_erp.accounting.models import JournalEntry
from apps.core_erp.outbox_models import OutboxEvent
from django.utils import timezone
from rest_framework.exceptions import PermissionDenied
class HotelSalesChecks(unittest.TestCase):
 def setUp(self):
  self.base=fixture['TourismMetricsChecks']();self.base.setUp();self.company=self.base.company;self.provider=self.base.provider;self.scope={'actor':self.base.owner,'provider_id':self.provider.pk};self.day=self.base.day;self.ids=[str(r.pk) for r in self.base.rooms];self.base.record(self.base.review())
 def review(self,**kw):return sales.review_sales(**self.scope,**{'day':self.day,'sold_room_ids':[self.ids[0]],'evidence_digest':'b'*64,'expected_revision':0,'confirmed':True,**kw})
 def record(self,r,**kw):return sales.record_sales(**self.scope,review_id=r['review_id'],confirmed=kw.get('confirmed',True))
 def result(self,**kw):return self.base.metrics(**kw)
 def test_half_occupancy_and_adr_reconcile_to_posted_revenue(self):
  self.record(self.review());r=self.result();self.assertEqual(r['occupancy_percent'],'50.0000');self.assertEqual(r['adr'],'10.0000');self.assertEqual(r['sold_room_days'],1);self.assertEqual(r['revpar'],'5.0000');self.assertEqual(r['goppar'],'4.0000');self.assertIsNone(r['sales_unavailable_reason'])
 def test_full_occupancy_and_two_night_average(self):
  self.record(self.review(sold_room_ids=self.ids));r=self.result();self.assertEqual(r['occupancy_percent'],'100.0000');self.assertEqual(r['adr'],'5.0000')
 def test_missing_sales_are_unknown_not_zero_or_inferred(self):
  r=self.result();self.assertIsNone(r['occupancy_percent']);self.assertIsNone(r['adr']);self.assertIsNone(r['sold_room_days']);self.assertEqual(r['sales_unavailable_reason'],'MISSING_SOLD_ROOM_NIGHTS');self.assertEqual(r['revpar'],'5.0000')
 def test_explicit_zero_sales_reports_zero_occupancy_but_unknown_adr(self):
  self.record(self.review(sold_room_ids=[]));r=self.result();self.assertEqual(r['occupancy_percent'],'0.0000');self.assertIsNone(r['adr']);self.assertEqual(r['sales_unavailable_reason'],'ZERO_SOLD_ROOM_NIGHTS')
 def test_both_authorizations_are_required(self):
  with self.assertRaises(AccountingError):self.review(confirmed=False)
  r=self.review()
  with self.assertRaises(AccountingError):self.record(r,confirmed=False)
 def test_foreign_and_duplicate_room_nights_rejected(self):
  for ids in [[str(uuid.uuid4())],[self.ids[0],self.ids[0]]]:
   with self.assertRaises(AccountingError):self.review(sold_room_ids=ids)
 def test_current_capacity_is_required(self):
  # Use another current day only through explicit scope: removing the local fixture
  # observation simulates no capacity, never mutates production data.
  OutboxEvent.objects.filter(event_type=capacity.RECORDED,payload__company_id=str(self.company.pk)).delete()
  with self.assertRaises(AccountingError):self.review()
 def test_no_backfill_or_future_day(self):
  for delta in [-1,1]:
   with self.assertRaises(AccountingError):self.review(day=(timezone.localdate()+timedelta(days=delta)).isoformat())
 def test_capacity_change_invalidates_pending_sales_review(self):
  r=self.review();self.base.record(self.base.review(expected_revision=1))
  with self.assertRaises(AccountingError):self.record(r)
 def test_capacity_amendment_requires_new_sales_observation_preserves_old_cutoff(self):
  self.record(self.review());cutoff=timezone.now().isoformat();self.base.record(self.base.review(room_ids=[self.ids[0]],expected_revision=1));r=self.result();self.assertIsNone(r['adr']);self.assertEqual(r['sales_unavailable_reason'],'SALES_CAPACITY_VERSION_CHANGED');self.assertEqual(self.result(as_of=cutoff)['occupancy_percent'],'50.0000');self.record(self.review(expected_revision=1));self.assertEqual(self.result()['occupancy_percent'],'100.0000')
 def test_new_sales_version_replaces_not_adds_and_preserves_cutoff(self):
  self.record(self.review());cutoff=timezone.now().isoformat();self.record(self.review(sold_room_ids=self.ids,expected_revision=1));self.assertEqual(self.result()['sold_room_days'],2);self.assertEqual(self.result(as_of=cutoff)['sold_room_days'],1)
 def test_cutoff_before_sales_never_looks_ahead(self):
  cutoff=timezone.now().isoformat();self.record(self.review());self.assertIsNone(self.result(as_of=cutoff)['adr'])
 def test_retry_is_idempotent_and_no_financial_write(self):
  before=JournalEntry.plain_objects.count();r=self.review();self.record(r);count=OutboxEvent.objects.count();self.assertTrue(self.record(r)['replayed']);self.assertEqual(OutboxEvent.objects.count(),count);self.assertEqual(before,JournalEntry.plain_objects.count())
 def test_competing_reviews_cannot_overwrite_recorded_version(self):
  a=self.review();b=self.review(sold_room_ids=self.ids);self.record(a)
  with self.assertRaises(AccountingError):self.record(b)
 def test_expired_review_is_rejected(self):
  r=self.review()
  with patch.object(sales.timezone,'now',return_value=timezone.now()+timedelta(minutes=16)):
   with self.assertRaises(AccountingError):self.record(r)
 def test_other_owner_is_denied(self):
  with self.assertRaises(PermissionDenied):sales.sources(actor=self.base.case.other,provider_id=self.provider.pk)
 def test_recovery_does_not_restore_approvals(self):
  self.record(self.review());r=sales.sources(**self.scope);self.assertFalse(r['confirmations_restored']);self.assertTrue(r['read_only']);self.assertTrue(r['matches_current_capacity']);self.assertEqual(r['revision'],1)
 def test_altered_evidence_or_missing_review_blocks_reporting(self):
  r=self.review();self.record(r);OutboxEvent.objects.filter(pk=r['review_id']).delete()
  with self.assertRaises(AccountingError):self.result()
 def test_atomic_failure_to_seal_record_rolls_back(self):
  from django.db.models.query import QuerySet
  r=self.review();original=QuerySet.update
  def fail(q,**kwargs):
   if q.model is OutboxEvent and 'known_at' in kwargs.get('payload',{}):raise RuntimeError('Synthetic sealing failure')
   return original(q,**kwargs)
  with patch.object(QuerySet,'update',fail):
   with self.assertRaises(RuntimeError):self.record(r)
  self.assertFalse(sales.rows(self.company,self.provider).exists())
 def test_real_api_no_store_and_unknown_fields_rejected(self):
  from rest_framework.test import APIRequestFactory,force_authenticate
  from apps.prestadores.mi_negocio.gestion_contable.contabilidad.views import PlanCuentaViewSet
  def call(action,body,method='post'):
   r=getattr(APIRequestFactory(),method)('/fixture/?provider_id='+str(self.provider.pk),body,format='json');force_authenticate(r,user=self.base.owner);return PlanCuentaViewSet.as_view({method:action})(r)
  args={'day':self.day,'sold_room_ids':[self.ids[0]],'evidence_digest':'c'*64,'expected_revision':0,'confirmed':True};r=call('review_hotel_sales',args);self.assertEqual(r.status_code,200,r.data);self.assertIn('no-store',r['Cache-Control']);saved=call('record_hotel_sales',{'review_id':r.data['review_id'],'confirmed':True});self.assertEqual(saved.status_code,200,saved.data);self.assertEqual(call('review_hotel_sales',{**args,'tenant_id':str(uuid.uuid4())}).status_code,400)
if __name__=='__main__':unittest.main()
