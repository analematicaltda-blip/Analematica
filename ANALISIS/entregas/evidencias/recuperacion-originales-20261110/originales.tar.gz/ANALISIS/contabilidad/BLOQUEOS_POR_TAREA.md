# Bloqueos para aceptación completa

## ACC-001 · Validación monetaria exacta y aislamiento de cuentas

2/3 hitos. Pendiente: 9 pruebas ORM aisladas; no certifica posteo completo ni PostgreSQL

## ACC-002 · UUID de alta y guardas de asientos/líneas

2/3 hitos. Pendiente: Triggers SQL probados con posteo/contrapartida válidos; pendientes roles privilegiados, otras tablas, migración nativa real y auditoría/firma independiente según alcance.

## ACC-003 · Idempotencia y outbox en una transacción

2/3 hitos. Pendiente: Corte39: entrega local por leases, recibo único y proyección/acuse en transacción; reintentos y PostgreSQL. Publicación Kafka y deduplicación externa pendientes.

## ACC-004 · Periodos, concurrencia y contrapartidas

2/3 hitos. Pendiente: Reversión neutra y diagnóstico de conciliación probados; faltan conciliación real de legados, aperturas/ajustes aprobados, snapshot e interfaz y fuentes FX/diferencias según alcance.

## ACC-005 · Puente TourismProvider a Tenant y actor verificables

2/3 hitos. Pendiente: Lectura/escritura y recuperación de resultado incierto probadas entre ambos backends y navegador; faltan provisión/renovación e historia del vínculo, roles/SSO/migraciones reales y aceptación productiva. Sin atomicidad distribuida.

## ACC-006 · Monedas, FX y valoración

2/3 hitos. Pendiente: Corte principal bajo bloqueo de empresa y moneda histórica incompatible rechazados. No ofrece snapshot histórico de publicación ni valoración/revaluación y fuentes FX reales; conciliación y aperturas aprobadas pendientes.

## ACC-007 · Hash canónico versionado y controles SQL

2/3 hitos. Pendiente: Flujo central con rol limitado y backup/restore local probados; faltan permisos/rutas completos, revisión de UPDATE(id), roles reales, RLS/funciones privilegiadas y llaves/medios/RPO/RTO según alcance.

## ACC-008 · Contrato CRM y reserva hacia facturación

2/3 hitos. Pendiente: Revisiones, solicitud, reconocimiento/anticipos/contrapartida y escritura corporativa locales implementados. Falta emisión/acuse DIAN auténticos, conciliación bancaria independiente, múltiples anticipos, política normativa y aceptación profesional/productiva. Implementación68 conecta política declarada versionada a reserva y reconocimiento, con evidencia revalidada; COP/1–5 componentes/un único código de impuesto positivo/fecha igual. Retenciones positivas y múltiples impuestos se rechazan; faltan normativa, interfaz/recuperación completas, SQL/concurrencia específica y aceptación real. Implementación72 conecta proveedores/facturas nativos con captura idempotente, fuente/huella reservadas, dos confirmaciones y contrapartida en ambos paneles. UI de un concepto; pendientes historia sin captura, cambios controlados, devoluciones parciales, fiscalidad completa y cualificación profesional/productiva.

## ACC-009 · XML, representación y firma fiscal

2/3 hitos. Pendiente: Borrador UBL COP y representación en memoria en ambos paneles, cuatro documentos sintéticos válidos contra XSD UBL2.1 CS1 de referencia. Faltan anexo DIAN vigente, campos completos, CRM/solicitud y política revisada, PDF-A3, cifrado/custodia, firma XAdES, acuses auténticos y habilitación profesional/productiva. Implementación63 añade firma XAdES local de laboratorio con salida cifrada; no acredita certificado/política DIAN, PKIX/revocación/TSA, custodia hardware ni habilitación fiscal real. Implementación66 inicia H09 con verificación XMLDSig de acuses explícitamente de laboratorio y diario local de reintentos; no habilita transmisión ni estados oficiales, numeración o aceptación DIAN.

## ACC-010 · Envelope encryption cliente y recuperación

2/3 hitos. Pendiente: SDK y paquete cliente recuperable/rotable con HMAC/contexto/versiones, ambos paneles y rechazo de manipulación verificados. Faltan custodia/recuperación hardware o cliente cualificados, referencias/publicación BYOS y última versión/ramas, medios/backup reales, representación y validación física/productiva; sin revocación de copias anteriores.

## ACC-011 · Conectores BYOS y OAuth mínimos

2/3 hitos. Pendiente: API independiente/cliente HTTPS y paquetes versionados PostgreSQL probados con rol mínimo, revocación, concurrencia y restore aislados. Pendientes propiedad/dominio/TLS/credenciales/perfiles y ambos paneles provisionados reales, operación/retención/RPO/RTO/commit incierto y escritores privilegiados; sin acreditar OAuth/alternativas no implementadas, propiedad legal, HMAC servidor ni custodia real.

## ACC-012 · Órdenes, novedades y controles SG-SST

2/3 hitos. Pendiente: Implementación69 añade datos persistentes de autorización profesional cifrada, EPP, jornadas/descanso y revocaciones; permisos clínicos explícitos; despacho positivo de orden genérica con política provisionada y dos confirmaciones del titular; cierre hacia VALIDACION con jornada registrada, sin costo/nómina. Pendientes datos/habilitación profesional y política laboral legítimos, evidencia física/off-platform, procesos especializados, interfaces, migración histórica, PostgreSQL/concurrencia y custodia cualificada. No habilita producción ni actuación física.

## ACC-013 · Reglas de nómina, costos y provisiones

2/3 hitos. Pendiente: Suplementos por minutos/tasas/divisor y bases declarados operables con16 pruebas ORM nuevas y ambos paneles. Pendientes clasificación laboral oficial por horarios/festivos, enlace individual de minutos a jornadas, otras novedades/ausencias/viáticos, nómina electrónica, datos legítimos y cualificación productiva.

## ACC-014 · Impuestos y conciliación continua

2/3 hitos. Pendiente: Implementación70 añade hecho comercial declarado/revisado: compras/ventas, IVA descontable/generado y retenciones con cuentas por componente, asiento canónico y contrapartida, dos confirmaciones y recuperación. Pendientes fuentes nativas/documentales, deduplicación entre rutas, conciliación fiscal unificada, devoluciones parciales, interfaz, SQL/concurrencia PostgreSQL y revisión normativa/profesional. Las reservas conservan sus restricciones de retención/múltiples impuestos. No hay aceptación oficial, pagos ni emisión fiscal. Implementación71 atribuye reservas/hechos comerciales y contrapartidas en un registro integrado de activos/pasivos visible en ambos paneles; valida sumas y evidencia en lote. No completa normativa, fuentes nativas ni aceptación profesional. Implementación72 conecta proveedores/facturas nativos con captura idempotente, fuente/huella reservadas, dos confirmaciones y contrapartida en ambos paneles. UI de un concepto; pendientes historia sin captura, cambios controlados, devoluciones parciales, fiscalidad completa y cualificación profesional/productiva. Historial contable nativo implementado en ERP y Analemática: búsqueda por prefijo, páginas20, estados capturada/revisada/contabilizada/contrapartida y fuente cambiada; legado sin captura diferenciado sin inventar pruebas.10 casos motor/API,1 HTTP corporativo y5 de contrato nuevos;38 comprobaciones Chromium del recorrido completo. Faltan adopción revisada de legado, edición controlada, devoluciones parciales, fiscalidad completa y aceptación profesional/productiva. Devoluciones parciales nativas de compras de un concepto implementadas en ERP y Analemática:18 pruebas ORM,6 de contrato y1 HTTP nuevas;28 comprobaciones Chromium más38 de regresión de compras. Asientos contra separados, redondeo acumulado, capacidad restante, dos autorizaciones, recibos/pruebas idempotentes y atribución tributaria. Se bloquea contrapartida completa después de devoluciones y reversión genérica del ajuste. Pendientes más conceptos/componentes, casos pagados, corrección de devoluciones, integración del saldo operativo, nota fiscal válida y aceptación profesional/productiva. Corrección append-only de la última devolución activa implementada en ambos paneles:14 pruebas ORM,3 nuevas de contrato y recorrido HTTP existente ampliado.28 comprobaciones Chromium nuevas. Restituye exactamente capacidad/IVA/retención, conserva diarios/pruebas y reservas documentales, rechaza revisiones obsoletas y sigue orden inverso para preservar centavos. Pendientes más conceptos, casos pagados, conciliación de pagos/saldo operativo, contrapartida completa del original tras correcciones, nota fiscal legítima, PostgreSQL y aceptación profesional/productiva. Contrapartida completa tras corregir todas las devoluciones implementada en ambos paneles. Revisión/confirmación liga la conciliación al historial verificado; revisiones obsoletas, prueba faltante, saldo activo o reversión directa quedan bloqueados.13 pruebas nuevas del motor,2 nuevas de contrato y HTTP existente ampliado;28 comprobaciones Chromium nuevas. Tras el cierre, historial consultable con capacidad cero y nuevos ajustes rechazados. Pendientes varios conceptos, casos pagados, saldo operativo/otros pagos, documentos fiscales válidos, PostgreSQL y aceptación profesional/productiva.

## ACC-015 · Legacy bridge y open banking

2/3 hitos. Pendiente: Asignaciones parciales explícitas entre extractos implementadas en ambos paneles:4+6 sobre movimiento10, saldo disponible6 y luego0; ventana histórica declarada, conservación exacta, dos autorizaciones, recuperación y liberación por importe.13 casos ORM,2 HTTP y4 de contrato adicionales;22 comprobaciones Chromium nuevas. Faltan FX, calificación de períodos combinando pruebas parciales, volumen/archivado, PostgreSQL, autenticidad bancaria y aceptación profesional/productiva. No liquida facturas ni realiza pagos.

## ACC-016 · Proyecciones y ratios turísticos

2/3 hitos. Pendiente: Liquidez, RevPAR/GOPPAR, ocupación comercial y ADR sobre cuentas/capacidad/noches vendidas revisadas, con cortes temporales verificados localmente en ambos paneles. Pendientes fuentes legítimas independientes, ocupación física/gratuidades, inventario intradía, cupos de otras actividades, paquetes y dimensiones de costos, series/calibración, PostgreSQL y aceptación profesional/productiva.

## ACC-017 · Monte Carlo y recomendaciones

2/3 hitos. Pendiente: Motor de ventanas múltiples y UI de holdout individual probados; faltan interfaz de ventanas, series reales y cualificación profesional/calibración/rendimiento.

## ACC-018 · Factores de carbono y ledger ambiental

2/3 hitos. Pendiente: Cálculo y registro revisado persistente, versiones de factores y exclusión por código de actividad en ambos paneles/APIs; sin obligación ni crédito. Faltan fuentes/soportes legítimos, integración operativa y duplicados semánticos, búsqueda/cortes/exportación, incertidumbre, cualificación profesional y reconocimiento válido. Implementación65: correcciones append-only con dos revisiones y recuperación de valor efectivo en ambos paneles; faltan formularios de corrección, concurrencia PostgreSQL específica y controles de historia frente a SQL privilegiado.

## ACC-019 · Reportes ESG y marcos aplicables

2/3 hitos. Pendiente: Reporte ambiental parcial disponible en ERP y Analemática, con cortes económico/conocimiento, correcciones efectivas, fuentes/unidades, mapeo de marco declarado y exportación JSON con huella. Pendientes aplicabilidad profesional de GRI/SASB, factores y soportes legítimos, restantes componentes ESG/sociales/gobernanza, métricas sectoriales, volumen/archivado, PostgreSQL y aceptación independiente/productiva. No certifica, no infiere alcances ni reconoce pasivos/créditos.

## ACC-020 · Consultas NLP de solo lectura

2/3 hitos. Pendiente: Consulta determinista ERP y corporativa verificadas con fuentes reales del ledger de prueba y rechazo de inyección. Falta modelo abierto/privado evaluado, dataset, voz, más fuentes/roles, rendimiento y dispositivos reales; sin SQL libre ni acciones financieras.

## ACC-021 · RPA financiera con autorizaciones

2/3 hitos. Pendiente: Primer incremento: ensayo financiero persistente en ERP y puente corporativo con dos confirmaciones del mismo titular y revisión de importe/destino; idempotencia, vencimiento, cancelación y vínculo revocado probados. Sin pagos, trabajador bancario ni integración con motor de escritorio. Faltan UI, proveedor/beneficiario/soportes legítimos, autorizaciones resistentes a suplantación, recibos, concurrencia PostgreSQL, recuperación operacional y aceptación profesional/productiva.

## ACC-022 · Offline cifrado y conflictos

2/3 hitos. Pendiente: Borrador ambiental individual cifrado, CAS entre pestañas, exportación/restauración y reanudación online supervisada verificados. Faltan arranque/cache offline completos, más dominios, catálogo/retención/evicción, sincronización ampliada, SQLite/custodia nativa y dispositivos reales; sin liquidación ni autorizaciones offline.

## ACC-023 · Benchmark250ms y precisión IA

2/3 hitos. Pendiente: Primer incremento local: herramienta reproducible de benchmark con dataset/hardware/manifiesto, p50/p95/p99/máximo/errores y evaluador de predicciones con abstenciones.100 compras sintéticas en SQLite en memoria, cuatro flujos, sin HTTP/concurrencia; conciliación máxima547.209ms antes y134.922ms después de la optimización. No acredita250ms extremo a extremo ni99.8% IA: clasificador no ejecutado. Pendientes carga/hardware/dataset autorizados, cualificación y revisión independiente.

## ACC-024 · Recuperación, seguridad y despliegue

2/3 hitos. Pendiente: Flujo central con rol limitado y backup/restore local probados; faltan permisos/rutas completos, revisión de UPDATE(id), roles reales, RLS/funciones privilegiadas y llaves/medios/RPO/RTO según alcance.
