from django.db import migrations,models

class Migration(migrations.Migration):
    dependencies=[('wallet','0004_device_trust_and_independent_enrollment')]
    operations=[migrations.AlterField(model_name='wallettransferintent',name='state',field=models.CharField(max_length=12,default='PENDING',choices=[('PENDING','Pending'),('REVIEWED','Reviewed'),('EXECUTED','Executed'),('CANCELLED','Cancelled')]))]
