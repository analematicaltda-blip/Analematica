'use client';
import React,{useEffect,useRef} from 'react';
import '../../../ANALEMATICA-FRONTEND/js/bank-groups.js';
declare global {interface Window {SGACDBankGroups:{mount:(root:HTMLElement,options:{request:(action:string,payload:Record<string,unknown>,signal:AbortSignal)=>Promise<unknown>})=>{destroy:()=>void;clear:()=>void}}}}
const actions:Record<string,string>={bank_sources:'fuentes-conciliacion-bancaria',bank_group_sources:'fuentes-agrupacion-bancaria',review_bank_groups:'revisar-agrupacion-bancaria',confirm_bank_groups:'confirmar-agrupacion-bancaria',bank_group_state:'estado-agrupacion-bancaria',review_bank_group_release:'revisar-liberacion-agrupacion-bancaria',confirm_bank_group_release:'liberar-agrupacion-bancaria'};
export function BankGroups({identity,providerId,request}:{identity:string|null;providerId:string;request:(path:string,init?:RequestInit)=>Promise<Response>}){
 const root=useRef<HTMLElement|null>(null),requester=useRef(request);requester.current=request;
 useEffect(()=>{if(!identity||!providerId||!root.current||!window.SGACDBankGroups)return;const controller=window.SGACDBankGroups.mount(root.current,{request:async(action,payload,signal)=>{if(!actions[action])throw Error('Acción no admitida.');const read=action==='bank_sources',query=new URLSearchParams({provider_id:providerId});const response=await requester.current('/api/v1/mi-negocio/contable/contabilidad/cuentas/'+actions[action]+'/?'+query,{signal,...(read?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})});const raw=await response.json();if(!response.ok)throw Error('No se confirmó la agrupación. Recupera la misma fuente.');return raw?.success===true?raw.data:raw;}});return ()=>controller.destroy();},[identity,providerId]);
 return identity&&providerId?<section ref={root} aria-label="Agrupación bancaria revisada"/>:null;
}
